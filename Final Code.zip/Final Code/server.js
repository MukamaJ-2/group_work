require('dotenv').config();
const express = require('express');
const bcrypt = require('bcrypt');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const nodemailer = require('nodemailer');

const app = express();
const PORT = 5000;
const SECRET_KEY = process.env.JWT_SECRET || 'your_secret_key';
const usersFilePath = path.join(__dirname, 'users.json');

app.use(express.json());
app.use(cors());

// Read users from file
function readUsers() {
    return JSON.parse(fs.readFileSync(usersFilePath, 'utf8'));
}

// Write users to file
function writeUsers(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

// Generate JWT Token
function generateToken(user) {
    return jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: '1h' });
}

// Middleware to verify JWT token
function authenticateToken(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'Access Denied' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ message: 'Invalid Token' });
        req.user = user;
        next();
    });
}

// Register user
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    const users = readUsers();

    // Regular expression to allow only Gmail addresses
    const emailRegex = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

    // Check if email format is valid and is a Gmail account
    if (!emailRegex.test(email)) {
        return res.status(400).json({ message: 'Invalid email! Only Gmail accounts are allowed.' });
    }

    // Check if the user already exists
    if (users.find(user => user.email === email)) {
        return res.status(400).json({ message: 'User already exists!' });
    }

    // Hash the password and store the user
    const hashedPassword = await bcrypt.hash(password, 10);
    users.push({ name, email, password: hashedPassword });
    writeUsers(users);

    res.status(201).json({ message: 'Registration successful!' });
});

// Login user & issue JWT
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const users = readUsers();
    const user = users.find(user => user.email === email);

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ message: 'Invalid credentials!' });
    }

    const token = generateToken(user);
    res.json({ message: 'Login successful!', token, user: { name: user.name, email: user.email } });
});

// Get user profile (Protected Route)
app.get('/profile', authenticateToken, (req, res) => {
    const users = readUsers();
    const user = users.find(user => user.email === req.user.email);

    if (!user) {
        return res.status(404).json({ message: 'User not found!' });
    }

    res.json({ name: user.name, email: user.email });
});

// Password reset request
app.post('/forgot-password', (req, res) => {
    const { email } = req.body;
    const users = readUsers();
    const user = users.find(user => user.email === email);

    if (!user) {
        return res.status(404).json({ message: 'Email not found!' });
    }

    const token = jwt.sign({ email }, SECRET_KEY, { expiresIn: '10m' });
    sendResetEmail(email, token);
    res.json({ message: 'Password reset link sent to your email.' });
});

// Reset password
app.post('/reset-password', async (req, res) => {
    const { token, newPassword } = req.body;

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        const users = readUsers();
        const user = users.find(user => user.email === decoded.email);

        if (!user) {
            return res.status(404).json({ message: 'Invalid token' });
        }

        user.password = await bcrypt.hash(newPassword, 10);
        writeUsers(users);
        res.json({ message: 'Password reset successful!' });
    } catch (error) {
        res.status(400).json({ message: 'Invalid or expired token' });
    }
});

// Send email function
function sendResetEmail(email, token) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Password Reset Request',
        text: `Click the link to reset your password: http://localhost:5500/reset.html?token=${token}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) console.log(error);
        else console.log('Email sent: ' + info.response);
    });
}

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
